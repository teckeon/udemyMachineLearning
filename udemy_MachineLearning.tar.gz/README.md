# udemyMachineLearning
This is where I will be following along from the course on udemy
configured Rstudio with Git
